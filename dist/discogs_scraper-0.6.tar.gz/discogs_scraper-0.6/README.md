The aim of this project is to create software that llows the user to easily scrape data from discogs into multiple different formats.
Currently it is only a python file so python3 will have to be installed on your computer
